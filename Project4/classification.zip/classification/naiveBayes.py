# naiveBayes.py
# -------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and Pieter 
# Abbeel in Spring 2013.
# For more info, see http://inst.eecs.berkeley.edu/~cs188/pacman/pacman.html

import util
import classificationMethod
import math

class NaiveBayesClassifier(classificationMethod.ClassificationMethod):
    """
    See the project description for the specifications of the Naive Bayes classifier.

    Note that the variable 'datum' in this code refers to a counter of features
    (not to a raw samples.Datum).
    """
    def __init__(self, legalLabels):
        self.legalLabels = legalLabels
        self.type = "naivebayes"
        self.k = 1 # this is the smoothing parameter, ** use it in your train method **
        self.automaticTuning = False # Look at this flag to decide whether to choose k automatically ** use this in your train method **

    def setSmoothing(self, k):
        """
        This is used by the main method to change the smoothing parameter before training.
        Do not modify this method.
        """
        self.k = k

    def train(self, trainingData, trainingLabels, validationData, validationLabels):
        """
        Outside shell to call your method. Do not modify this method.
        """

        # might be useful in your code later...
        # this is a list of all features in the training set.
        self.features = list(set([ f for datum in trainingData for f in datum.keys() ]));

        if (self.automaticTuning):
            kgrid = [0.001, 0.01, 0.05, 0.1, 0.5, 1, 2, 5, 10, 20, 50]
        else:
            kgrid = [self.k]

        self.trainAndTune(trainingData, trainingLabels, validationData, validationLabels, kgrid)



    def trainAndTune(self, trainingData, trainingLabels, validationData, validationLabels, kgrid):
        """
        Trains the classifier by collecting counts over the training data, and
        stores the Laplace smoothed estimates so that they can be used to classify.
        Evaluate each value of k in kgrid to choose the smoothing parameter
        that gives the best accuracy on the held-out validationData.

        trainingData and validationData are lists of feature Counters.  The corresponding
        label lists contain the correct label for each datum.

        To get the list of all possible features or labels, use self.features and
        self.legalLabels.
        """

        # variables used
        pixelOnCountsPerLabel = util.Counter()  # pixelOnCountsPerLabel[label,feature] = # of times pixel is 1 for label
        labelCounter = util.Counter()           # labelCounter[label] = # of datums with this label in trainingData
        allpairs = [(x, y) for x in self.legalLabels for y in self.features]    # all pairs of features and labels
        accuracies = util.Counter()             # counter to store
        best = 0

        # collecting counts from training data
        for datum, label in zip(trainingData, trainingLabels):
            labelCounter[label] += 1
            for feature in self.features:
                if datum[feature] > 0:
                    pixelOnCountsPerLabel[label, feature] += 1

        # calculate probability of each label P(Y) (Not smoothed)
        self.labelProbs = labelCounter.copy()   # labelProbs[label] = probabilities of any datum being a certain label
        self.labelProbs.normalize()

        # evaluate each value of k in kgrid to choose smoothing param
        for k in kgrid:
            self.probOn = pixelOnCountsPerLabel.copy()      # will store probabilities smoothed by current k value
            self.probOn.incrementAll(allpairs, k)           # smoothing (totals smoothed by 2*k in normalize loop below)
            for key, val in self.probOn.items():            # normalize (priors already normalized)
                self.probOn[key] = val / (labelCounter[key[0]] + 2.0 * k)  # key[0] is the label in (label, feature)
            guesses = self.classify(validationData)
            correct = [guesses[i] == validationLabels[i] for i in range(len(validationLabels))].count(True)
            accuracy = 100.0 * correct / len(validationLabels)
            accuracies[k] = accuracy
            print "K = " + str(k) + ": " + str(correct), \
                ("correct out of " + str(len(validationLabels)) + " (%.1f%%).") % accuracy
            if accuracy > best:
                best = accuracy
                bestData = self.probOn
        self.setSmoothing(accuracies.argMax())
        self.probOn = bestData

    def classify(self, testData):
        """
        Classify the data based on the posterior distribution over labels.

        You shouldn't modify this method.
        """
        guesses = []
        self.posteriors = [] # Log posteriors are stored for later data analysis (autograder).
        for datum in testData:
            posterior = self.calculateLogJointProbabilities(datum)
            guesses.append(posterior.argMax())
            self.posteriors.append(posterior)
        return guesses

    def calculateLogJointProbabilities(self, datum):
        """
        Returns the log-joint distribution over legal labels and the datum.
        Each log-probability should be stored in the log-joint counter, e.g.
        logJoint[3] = <Estimate of log( P(Label = 3, datum) )>

        To get the list of all possible features or labels, use self.features and
        self.legalLabels.
        """
        logJoint = util.Counter()
        for label in self.legalLabels:
            logProb = 0
            for feature in self.features:
                if datum[feature] > 0:
                    logProb += math.log(self.probOn[label, feature])
                else:
                    logProb += math.log(1.0 - self.probOn[label, feature])
            logJoint[label] = logProb + math.log(self.labelProbs[label])
        return logJoint

    def findHighOddsFeatures(self, label1, label2):
        """
        Returns the 100 best features for the odds ratio:
                P(feature=1 | label1)/P(feature=1 | label2)

        Note: you may find 'self.features' a useful way to loop through all possible features
        """
        featuresOdds = []

        for feature in self.features:
            featuresOdds.append((self.probOn[label1, feature] / self.probOn[label2, feature], feature))
        featuresOdds.sort(reverse=True)
        featuresOdds = [feature for val, feature in featuresOdds[:100]]

        return featuresOdds
